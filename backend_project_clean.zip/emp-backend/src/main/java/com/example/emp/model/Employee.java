
package com.example.emp.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "employees")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fname;
    private String lname;
    private String email;

    private BigDecimal salary;
    private String department;
    private String designation;

    private LocalDate joiningDate;

    @Column(length = 1000)
    private String taskInfo;

    private String taskStatus; // Pending | In Progress | Completed

    public Long getId() { 
    	return id; 
    }
    public void setId(Long id) { 
    	this.id = id; 
    }
    public String getFname() { 
    	return fname; 
    }
    public void setFname(String fname) { 
    	this.fname = fname; 
    }
    public String getLname() { 
    	return lname; 
    }
    public void setLname(String lname) { 
    	this.lname = lname; 
    }
    public String getEmail() { 
    	return email; 
    }
    public void setEmail(String email) { 
    	this.email = email; 
    }
    public java.math.BigDecimal getSalary() { 
    	return salary; 
    }
    public void setSalary(java.math.BigDecimal salary) { 
    	this.salary = salary; 
    }
    public String getDepartment() { 
    	return department; 
    }
    public void setDepartment(String department) { 
    	this.department = department; 
    }
    public String getDesignation() { 
    	return designation; 
    }
    public void setDesignation(String designation) { 
    	this.designation = designation; 
    }
    public java.time.LocalDate getJoiningDate() { 
    	return joiningDate; 
    }
    public void setJoiningDate(java.time.LocalDate joiningDate) { 
    	this.joiningDate = joiningDate; 
    }
    public String getTaskInfo() { 
    	return taskInfo; 
    }
    public void setTaskInfo(String taskInfo) { 
    	this.taskInfo = taskInfo; 
    }
    public String getTaskStatus() { 
    	return taskStatus; 
    }
    public void setTaskStatus(String taskStatus) { 
    	this.taskStatus = taskStatus; 
    }
}
