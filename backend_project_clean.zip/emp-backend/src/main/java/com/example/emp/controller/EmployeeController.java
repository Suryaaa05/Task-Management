
package com.example.emp.controller;

import com.example.emp.exception.ResourceNotFoundException;
import com.example.emp.model.Employee;
import com.example.emp.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/employees")
@CrossOrigin(origins = "http://localhost:4200", allowedHeaders = "*", exposedHeaders = "*")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(employeeRepository.findAll());
    }

    @PostMapping
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        if (employee.getTaskStatus() == null || employee.getTaskStatus().isBlank()) {
            employee.setTaskStatus("Pending");
        }
        Employee saved = employeeRepository.save(employee);
        return ResponseEntity.status(201).body(saved);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee with id " + id + " does not exist"));
        return ResponseEntity.ok(employee);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee details) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee with id " + id + " does not exist"));

        employee.setFname(details.getFname());
        employee.setLname(details.getLname());
        employee.setEmail(details.getEmail());
        employee.setSalary(details.getSalary());
        employee.setDepartment(details.getDepartment());
        employee.setDesignation(details.getDesignation());
        employee.setJoiningDate(details.getJoiningDate());
        employee.setTaskInfo(details.getTaskInfo());
        employee.setTaskStatus(details.getTaskStatus());

        return ResponseEntity.ok(employeeRepository.save(employee));
    }

    public static class StatusUpdateRequest {
        public String taskStatus;
        public String getTaskStatus() { return taskStatus; }
        public void setTaskStatus(String taskStatus) { this.taskStatus = taskStatus; }
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<Employee> updateTaskStatus(@PathVariable Long id, @RequestBody StatusUpdateRequest body) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee with id " + id + " does not exist"));
        if (body == null || body.taskStatus == null || body.taskStatus.isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        employee.setTaskStatus(body.taskStatus);
        return ResponseEntity.ok(employeeRepository.save(employee));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, Boolean>> deleteEmployee(@PathVariable Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee with id " + id + " does not exist"));
        employeeRepository.delete(employee);
        Map<String, Boolean> response = new HashMap<>();
        response.put("Deleted", Boolean.TRUE);
        return ResponseEntity.ok(response);
    }
}
