
# emp-backend (Spring Boot + Maven, Eclipse-ready)

- Port: **8083**
- Base: `http://localhost:8083/api/v1/employees`
- No Spring Security. CORS allows `http://localhost:4200`.

## Import in Eclipse (m2e)
1. **File → Import… → Maven → Existing Maven Projects**
2. Select this folder (where `pom.xml` lives).
3. Finish. (m2e will resolve dependencies)
4. Right click project → Run As → Spring Boot App (or Java Application with `EmpApplication`)

## DB Setup
- Create DB: `CREATE DATABASE emp;`
- Edit credentials: `src/main/resources/application.properties`
- `spring.jpa.hibernate.ddl-auto=update` will create/update tables.

## API
- `GET /api/v1/employees`
- `GET /api/v1/employees/{id}`
- `POST /api/v1/employees`
- `PUT /api/v1/employees/{id}`
- `PATCH /api/v1/employees/{id}/status`  body: `{ "taskStatus": "Completed" }`
- `DELETE /api/v1/employees/{id}`
